# HR Analytics Dashboard – Power BI

An interactive **HR Analytics Dashboard** built in Microsoft Power BI to analyze employee attrition, salary, age, education, job roles, and years at the company.

## Dashboard Preview

![HR Analytics Dashboard](dashboard_preview.png)

## Key KPIs

- **Total Employees:** 1,480
- **Attrition:** 238
- **Attrition Rate:** 16.08%
- **Average Employee Age:** 37
- **Average Salary:** 7K
- **Average Years at Company:** 7

## Dashboard Analysis

The dashboard provides visual analysis of:

- Attrition by Education Field
- Attrition by Age Group
- Attrition by Salary Range
- Attrition by Years at Company
- Attrition by Job Role
- Attrition by Gender
- Department-level filtering
- Job-role attrition breakdown

## Tools Used

- Microsoft Power BI
- Power Query
- DAX
- Data Visualization
- HR Analytics

## Suggested Repository Structure

```text
HR-Analytics-Dashboard/
├── README.md
├── dashboard_preview.png
└── HR_Analytics_Dashboard.pbix
```

> Add your actual `.pbix` Power BI file to this folder before uploading the complete project to GitHub.

## How to Use

1. Download or clone this repository.
2. Open `HR_Analytics_Dashboard.pbix` in Microsoft Power BI Desktop.
3. Refresh the data if the original dataset is available.
4. Use the dashboard filters to explore employee attrition.

## Note

The screenshot in this repository is a preview of the Power BI dashboard. The `.pbix` file should be added separately if you want others to open and interact with the report.
